using System.Net.Http;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Http;

var builder = WebApplication.CreateBuilder(args);

// HttpClient'ы для бизнес-сервисов
builder.Services.AddHttpClient("FileStorage", client =>
{
    var baseUrl = builder.Configuration["Services:FileStorage"] ?? "http://file-storage:8080";
    client.BaseAddress = new Uri(baseUrl);
});

builder.Services.AddHttpClient("Analysis", client =>
{
    var baseUrl = builder.Configuration["Services:Analysis"] ?? "http://analysis:8080";
    client.BaseAddress = new Uri(baseUrl);
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

// POST /api/works/submit
app.MapPost("/api/works/submit", async (
    HttpRequest request,
    IHttpClientFactory httpClientFactory) =>
{
    if (!request.HasFormContentType)
        return Results.BadRequest("Expected multipart/form-data");

    var form = await request.ReadFormAsync();
    var file = form.Files["file"];

    if (file is null || file.Length == 0)
        return Results.BadRequest("file is required");

    var studentId = form["studentId"].ToString();
    var studentName = form["studentName"].ToString();
    var assignmentId = form["assignmentId"].ToString();

    if (string.IsNullOrWhiteSpace(studentId) || string.IsNullOrWhiteSpace(assignmentId))
        return Results.BadRequest("studentId and assignmentId are required");

    var fileClient = httpClientFactory.CreateClient("FileStorage");
    StoredFileDto? storedFile;

    // 1. Отправляем файл в FileStorageService
    try
    {
        using var content = new MultipartFormDataContent();
        var streamContent = new StreamContent(file.OpenReadStream());
        content.Add(streamContent, "file", file.FileName);
        content.Add(new StringContent(studentId), "studentId");
        content.Add(new StringContent(studentName ?? string.Empty), "studentName");
        content.Add(new StringContent(assignmentId), "assignmentId");

        var resp = await fileClient.PostAsync("/api/files", content);

        if (!resp.IsSuccessStatusCode)
        {
            var body = await resp.Content.ReadAsStringAsync();
            return Results.Problem(
                $"FileStorageService error {(int)resp.StatusCode}: {body}",
                statusCode: (int)resp.StatusCode);
        }

        storedFile = await resp.Content.ReadFromJsonAsync<StoredFileDto>();
        if (storedFile is null)
        {
            return Results.Problem("FileStorageService returned empty body",
                statusCode: StatusCodes.Status502BadGateway);
        }
    }
    catch (HttpRequestException ex)
    {
        return Results.Problem(
            "FileStorageService unavailable: " + ex.Message,
            statusCode: StatusCodes.Status503ServiceUnavailable);
    }

    // 2. Запускаем анализ
    AnalysisReportDto? report = null;
    string analysisStatus;

    try
    {
        var analysisClient = httpClientFactory.CreateClient("Analysis");
        var analyzeRequest = new AnalyzeRequest(
            storedFile.Id,
            storedFile.AssignmentId,
            storedFile.StudentId);

        var resp = await analysisClient.PostAsJsonAsync("/api/reports/analyze", analyzeRequest);

        if (resp.IsSuccessStatusCode)
        {
            report = await resp.Content.ReadFromJsonAsync<AnalysisReportDto>();
            analysisStatus = "Completed";
        }
        else
        {
            analysisStatus = $"ErrorFromAnalysisService:{(int)resp.StatusCode}";
        }
    }
    catch (HttpRequestException)
    {
        analysisStatus = "AnalysisServiceUnavailable";
    }

    var result = new SubmitWorkResponse(storedFile, report, analysisStatus);
    return Results.Ok(result);
})
.WithName("SubmitWork")
.Produces<SubmitWorkResponse>();

// GET /api/works/{assignmentId}/reports
app.MapGet("/api/works/{assignmentId}/reports", async (
    string assignmentId,
    IHttpClientFactory httpClientFactory) =>
{
    var analysisClient = httpClientFactory.CreateClient("Analysis");
    try
    {
        var resp = await analysisClient.GetAsync($"/api/reports/by-assignment/{assignmentId}");
        if (!resp.IsSuccessStatusCode)
        {
            var body = await resp.Content.ReadAsStringAsync();
            return Results.Problem(
                $"AnalysisService error {(int)resp.StatusCode}: {body}",
                statusCode: (int)resp.StatusCode);
        }

        var bodyJson = await resp.Content.ReadAsStringAsync();
        return Results.Content(bodyJson, "application/json");
    }
    catch (HttpRequestException)
    {
        return Results.Problem(
            "AnalysisService unavailable",
            statusCode: StatusCodes.Status503ServiceUnavailable);
    }
})
.WithName("GetReportsForAssignment");

app.Run();

// DTO'шки (должны совпадать по структуре с ответами сервисов)
record StoredFileDto(
    Guid Id,
    string StudentId,
    string? StudentName,
    string AssignmentId,
    DateTimeOffset UploadedAt,
    string OriginalFileName,
    string RelativePath
);

record AnalyzeRequest(Guid FileId, string AssignmentId, string StudentId);

record AnalysisReportDto(
    Guid Id,
    Guid FileId,
    string StudentId,
    string AssignmentId,
    DateTimeOffset CreatedAt,
    bool IsPlagiarism,
    Guid? PlagiarismSourceFileId,
    string WordCloudUrl
);

record SubmitWorkResponse(
    StoredFileDto Submission,
    AnalysisReportDto? Report,
    string AnalysisStatus
);
