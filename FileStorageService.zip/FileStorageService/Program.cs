using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<FileStorageDbContext>(options =>
{
    var conn = builder.Configuration.GetConnectionString("DefaultConnection")
               ?? "Data Source=filestorage.db";
    options.UseSqlite(conn);
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<FileStorageDbContext>();
    db.Database.EnsureCreated();
}

app.UseSwagger();
app.UseSwaggerUI();

var filesRoot = Path.Combine(Directory.GetCurrentDirectory(), "files");
Directory.CreateDirectory(filesRoot);

// POST /api/files — загрузка файла
app.MapPost("/api/files", async (HttpRequest request, FileStorageDbContext db) =>
{
    if (!request.HasFormContentType)
        return Results.BadRequest("Expected multipart/form-data");

    var form = await request.ReadFormAsync();
    var file = form.Files["file"];

    if (file is null || file.Length == 0)
        return Results.BadRequest("file is required");

    var studentId = form["studentId"].ToString();
    var studentName = form["studentName"].ToString();
    var assignmentId = form["assignmentId"].ToString();

    if (string.IsNullOrWhiteSpace(studentId) || string.IsNullOrWhiteSpace(assignmentId))
        return Results.BadRequest("studentId and assignmentId are required");

    var id = Guid.NewGuid();
    var ext = Path.GetExtension(file.FileName);
    var relativePath = Path.Combine(assignmentId, $"{id}{ext}");
    var fullPath = Path.Combine(filesRoot, relativePath);

    Directory.CreateDirectory(Path.GetDirectoryName(fullPath)!);

    await using (var stream = File.Create(fullPath))
    {
        await file.CopyToAsync(stream);
    }

    var entity = new StoredFile
    {
        Id = id,
        StudentId = studentId,
        StudentName = string.IsNullOrWhiteSpace(studentName) ? null : studentName,
        AssignmentId = assignmentId,
        UploadedAt = DateTimeOffset.UtcNow,
        OriginalFileName = file.FileName,
        RelativePath = relativePath.Replace('\\', '/')
    };

    db.Files.Add(entity);
    await db.SaveChangesAsync();

    var dto = new StoredFileDto(
        entity.Id,
        entity.StudentId,
        entity.StudentName,
        entity.AssignmentId,
        entity.UploadedAt,
        entity.OriginalFileName,
        entity.RelativePath
    );

    return Results.Created($"/api/files/{entity.Id}/meta", dto);
})
.WithName("UploadFile")
.Produces<StoredFileDto>(StatusCodes.Status201Created);

// GET /api/files/{id}/meta — метаданные
app.MapGet("/api/files/{id:guid}/meta", async (Guid id, FileStorageDbContext db) =>
{
    var entity = await db.Files.FindAsync(id);
    if (entity is null)
        return Results.NotFound();

    var dto = new StoredFileDto(
        entity.Id,
        entity.StudentId,
        entity.StudentName,
        entity.AssignmentId,
        entity.UploadedAt,
        entity.OriginalFileName,
        entity.RelativePath
    );

    return Results.Ok(dto);
})
.WithName("GetFileMeta")
.Produces<StoredFileDto>();

// GET /api/files/{id}/content — сам файл
app.MapGet("/api/files/{id:guid}/content", async (Guid id, FileStorageDbContext db) =>
{
    var entity = await db.Files.FindAsync(id);
    if (entity is null)
        return Results.NotFound("File metadata not found");

    var fullPath = Path.Combine(filesRoot, entity.RelativePath);
    if (!File.Exists(fullPath))
        return Results.NotFound("File on disk not found");

    var stream = File.OpenRead(fullPath);
    return Results.File(stream, "application/octet-stream", entity.OriginalFileName);
})
.WithName("GetFileContent");

app.Run();

class FileStorageDbContext : DbContext
{
    public FileStorageDbContext(DbContextOptions<FileStorageDbContext> options)
        : base(options) { }

    public DbSet<StoredFile> Files => Set<StoredFile>();
}

class StoredFile
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    public string StudentId { get; set; } = default!;

    public string? StudentName { get; set; }

    [Required]
    public string AssignmentId { get; set; } = default!;

    public DateTimeOffset UploadedAt { get; set; }

    [Required]
    public string OriginalFileName { get; set; } = default!;

    [Required]
    public string RelativePath { get; set; } = default!;
}

record StoredFileDto(
    Guid Id,
    string StudentId,
    string? StudentName,
    string AssignmentId,
    DateTimeOffset UploadedAt,
    string OriginalFileName,
    string RelativePath
);
