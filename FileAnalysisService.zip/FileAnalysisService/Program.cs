using System.ComponentModel.DataAnnotations;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AnalysisDbContext>(options =>
{
    var conn = builder.Configuration.GetConnectionString("DefaultConnection")
               ?? "Data Source=analysis.db";
    options.UseSqlite(conn);
});

// HttpClient для общения с FileStorageService
builder.Services.AddHttpClient("FileStorage", (sp, client) =>
{
    var config = sp.GetRequiredService<IConfiguration>();
    var baseUrl = config["Services:FileStorage"] ?? "http://file-storage:8080";
    client.BaseAddress = new Uri(baseUrl);
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AnalysisDbContext>();
    db.Database.EnsureCreated();
}

app.UseSwagger();
app.UseSwaggerUI();

// POST /api/reports/analyze
app.MapPost("/api/reports/analyze", async (
    AnalyzeRequest request,
    AnalysisDbContext db,
    IHttpClientFactory httpClientFactory) =>
{
    // 1. Получаем содержимое файла
    string text;
    try
    {
        var client = httpClientFactory.CreateClient("FileStorage");
        var response = await client.GetAsync($"/api/files/{request.FileId}/content");

        if (!response.IsSuccessStatusCode)
        {
            return Results.Problem(
                $"FileStorageService returned {(int)response.StatusCode}",
                statusCode: (int)response.StatusCode);
        }

        var bytes = await response.Content.ReadAsByteArrayAsync();
        text = Encoding.UTF8.GetString(bytes);
    }
    catch (HttpRequestException)
    {
        return Results.Problem(
            "FileStorageService unavailable",
            statusCode: StatusCodes.Status503ServiceUnavailable);
    }

    // Нормализация текста (простая)
    var normalized = text
        .Replace("\r\n", "\n")
        .Replace("\r", "\n")
        .ToLowerInvariant();

    var hashBytes = SHA256.HashData(Encoding.UTF8.GetBytes(normalized));
    var hash = Convert.ToHexString(hashBytes);

    var now = DateTimeOffset.UtcNow;

    // 2. Ищем более раннюю сдачу с таким же хэшем
    var previous = await db.Reports
        .Where(r =>
            r.AssignmentId == request.AssignmentId &&
            r.FileHash == hash &&
            r.StudentId != request.StudentId &&
            r.CreatedAt < now)
        .OrderBy(r => r.CreatedAt)
        .FirstOrDefaultAsync();

    var isPlagiarism = previous is not null;

    // 3. Формируем URL облака слов
    var wordCloudUrl = BuildWordCloudUrl(normalized);

    var report = new AnalysisReport
    {
        Id = Guid.NewGuid(),
        FileId = request.FileId,
        StudentId = request.StudentId,
        AssignmentId = request.AssignmentId,
        CreatedAt = now,
        IsPlagiarism = isPlagiarism,
        PlagiarismSourceFileId = previous?.FileId,
        FileHash = hash,
        WordCloudUrl = wordCloudUrl
    };

    db.Reports.Add(report);
    await db.SaveChangesAsync();

    var dto = new AnalysisReportDto(
        report.Id,
        report.FileId,
        report.StudentId,
        report.AssignmentId,
        report.CreatedAt,
        report.IsPlagiarism,
        report.PlagiarismSourceFileId,
        report.WordCloudUrl
    );

    return Results.Created($"/api/reports/{report.Id}", dto);
})
.WithName("AnalyzeFile")
.Produces<AnalysisReportDto>(StatusCodes.Status201Created);

// GET /api/reports/by-assignment/{assignmentId}
app.MapGet("/api/reports/by-assignment/{assignmentId}", async (
    string assignmentId,
    AnalysisDbContext db) =>
{
    var items = await db.Reports
        .Where(r => r.AssignmentId == assignmentId)
        .OrderByDescending(r => r.CreatedAt)
        .Select(r => new AnalysisReportDto(
            r.Id,
            r.FileId,
            r.StudentId,
            r.AssignmentId,
            r.CreatedAt,
            r.IsPlagiarism,
            r.PlagiarismSourceFileId,
            r.WordCloudUrl))
        .ToListAsync();

    return Results.Ok(items);
})
.WithName("GetReportsByAssignment")
.Produces<List<AnalysisReportDto>>();

app.Run();

// Локальный helper
static string BuildWordCloudUrl(string text)
{
    var baseUrl = "https://quickchart.io/wordcloud";
    var encoded = Uri.EscapeDataString(text);
    return $"{baseUrl}?text={encoded}&width=600&height=400&maxNumWords=50";
}

class AnalysisDbContext : DbContext
{
    public AnalysisDbContext(DbContextOptions<AnalysisDbContext> options)
        : base(options) { }

    public DbSet<AnalysisReport> Reports => Set<AnalysisReport>();
}

class AnalysisReport
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    public Guid FileId { get; set; }

    [Required]
    public string StudentId { get; set; } = default!;

    [Required]
    public string AssignmentId { get; set; } = default!;

    public DateTimeOffset CreatedAt { get; set; }

    public bool IsPlagiarism { get; set; }

    public Guid? PlagiarismSourceFileId { get; set; }

    [Required]
    public string FileHash { get; set; } = default!;

    [Required]
    public string WordCloudUrl { get; set; } = default!;
}

record AnalyzeRequest(Guid FileId, string AssignmentId, string StudentId);

record AnalysisReportDto(
    Guid Id,
    Guid FileId,
    string StudentId,
    string AssignmentId,
    DateTimeOffset CreatedAt,
    bool IsPlagiarism,
    Guid? PlagiarismSourceFileId,
    string WordCloudUrl
);
